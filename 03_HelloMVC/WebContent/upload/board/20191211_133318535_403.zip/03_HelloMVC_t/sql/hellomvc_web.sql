--=======================================
--WEB계정
--=======================================
--member테이블 생성
create table member(
    memberid varchar2(15),
    password varchar2(300) not null,
    membername varchar2(30) not null,
    gender char(1),
    age number,
    email varchar2(30),
    phone char(11) not null,
    address varchar2(300),
    hobby varchar2(300),
    enrolldate date default sysdate,
    constraint pk_member_id primary key(memberid),
    constraint ch_member_gender check(gender in ('M','F'))
);

insert into member
values('abcde','1234','알파치노','M',45, 
      'abcde@naver.com','01012341234','서울시 강남구 역삼동', '운동,등산,독서',default);
insert into member
values('honggd','1234','홍길동','M',35, 
      'honggd@naver.com','01012341234','서울시 중구 동대문동', '등산,독서',default);
insert into member
values('sinsa','1234','신사임당','F',53, 
      'sinsa@naver.com','01012341234','서울시 관악구 인헌동', '독서',default);
--관리자계정 추가
insert into member
values('admin','1234','관리자','M',16, 
      'admin@iei.or.kr','01012341234','서울시 강동구', '게임,독서',default);

--조회
select * from member;


--커밋
commit;

--기존회원들 비밀번호 모두 변경
update member 
set password = '1ARVn2Auq2/WAqx2gNrL+q3RNjAzXpUfCXrzkA6d4Xa22yhRLy4AC50E+6UTPoscbo31nbOoq51gvkuXzJ6B2w==';
commit;


--회원관리 페이징처리
--조회
select * from member;

--페이징쿼리
--rownum이용방법
select *
from(
    select rownum rnum, V.*
    from(
        select *
        from member
        order by enrolldate desc) V) V
where rnum between 11 and 20;










